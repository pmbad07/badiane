package com.ism.services;

import com.ism.entities.ArticleConfection;

import java.util.ArrayList;

public class ArticleConfectionServiceImpl implements ArticleConfectionService {

    @Override
    public int add(ArticleConfection data) {
        return 0;
    }

    @Override
    public ArrayList<ArticleConfection> getAll() {
        return null;
    }

    @Override
    public int update(ArticleConfection data) {
        return 0;
    }

    @Override
    public ArticleConfection show(int id) {
        return null;
    }

    @Override
    public int remove(int id) {
        return 0;
    }

    @Override
    public int[] remove(int[] ids) {
        return new int[0];
    }
}

package com.ism;
import com.ism.entities.Categorie;
import com.ism.repositories.ITables;
import com.ism.repositories.bd.CategorieRepository;
import com.ism.repositories.list.TableCategories;
import com.ism.services.CategorieService;
import com.ism.services.CategorieServiceImpl;

import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        ITables<Categorie> repository=new TableCategories();
        CategorieServiceImpl categorieServiceImpl=new CategorieServiceImpl(repository);
       int choix;
       Scanner scanner=new Scanner(System.in);
       do{
           System.out.println("1-Ajouter");
           System.out.println("2-Lister");
           System.out.println("3-Modifier");
           System.out.println("4-Editer");
           System.out.println("5-Supprimer (simple et multiple)");
           System.out.println("6-Quitter");
           choix= scanner.nextInt();
           scanner.nextLine();

           switch (choix){
               case 1:
                   System.out.println("Entrez le libelle");
                   Categorie categorie=new Categorie(scanner.nextLine());
                   categorieServiceImpl.add(categorie);
                   break;
               case 2:
                  categorieServiceImpl.getAll().forEach(System.out::println);
                   break;
                
                case 3:
                   System.out.println("Entrez l'ID de la catégorie à modifier :");
                   int idToUpdate = scanner.nextInt();
                   scanner.nextLine(); 
                   System.out.println("Entrez le nouveau libellé :");
                   String newLibelle = scanner.nextLine();
                   Categorie updatedCategorie = new Categorie(newLibelle);
                   categorieServiceImpl.update(idToUpdate, updatedCategorie);
                   break;
               case 4:
                   System.out.println("Entrez l'ID de la catégorie à éditer :");
                   int idToEdit = scanner.nextInt();
                   scanner.nextLine(); 
                   System.out.println("Entrez le nouveau libellé :");
                   String editedLibelle = scanner.nextLine();
                   categorieServiceImpl.edit(idToEdit, editedLibelle);
                   break;
               case 5:
                   System.out.println("Entrez l'ID de la catégorie à supprimer :");
                   int idToDelete = scanner.nextInt();
                   categorieServiceImpl.delete(idToDelete);
                   break;
               case 6:
                   System.out.println("Quitter le programme.");
                   break;
               default:
                   System.out.println("Choix invalide.");
                   break;
           }
               default:
                   break;
           }
           
           
       }while(choix!=3);
    }
}


package com.ism.repositories.list;

import com.ism.entities.Categorie;
import com.ism.repositories.Table;

public class TableCategories extends Table<Categorie> {

}

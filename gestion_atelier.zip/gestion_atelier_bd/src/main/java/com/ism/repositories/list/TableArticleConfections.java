package com.ism.repositories.list;

import com.ism.entities.ArticleConfection;
import com.ism.repositories.Table;

public class TableArticleConfections extends Table<ArticleConfection> {


}

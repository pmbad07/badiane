package com.ism.repositories.list;

import com.ism.entities.Unite;
import com.ism.repositories.Table;

public class TableUnites extends Table<Unite> {

}
